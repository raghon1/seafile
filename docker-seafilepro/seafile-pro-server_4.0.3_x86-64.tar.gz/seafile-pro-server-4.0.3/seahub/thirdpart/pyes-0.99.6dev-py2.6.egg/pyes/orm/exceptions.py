__author__ = 'alberto'
class DoesNotExist(Exception):
    pass


class MultipleObjectsReturned(Exception):
    pass

